package com.arman.queuetube.util.itemtouchhelper.viewholders;

public interface ItemTouchHelperViewHolder {

    void onItemSelected();
    void onItemClear();

}
