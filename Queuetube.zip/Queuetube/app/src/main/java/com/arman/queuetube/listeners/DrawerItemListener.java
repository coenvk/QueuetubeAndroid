package com.arman.queuetube.listeners;

import android.view.MenuItem;

import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.drawerlayout.widget.DrawerLayout;

public class DrawerItemListener implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;

    public DrawerItemListener(DrawerLayout drawerLayout) {
        this.drawerLayout = drawerLayout;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        if (item.isCheckable()) {
            item.setChecked(true);
            this.drawerLayout.closeDrawers();
            return true;
        }
        return false;
    }

}
